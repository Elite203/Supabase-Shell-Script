Require Dependencies
- Supabase CLI --> npx supabase --version
- Docker as requirement
- NodeJS , NPX
- brew install jq

The Supabase folder is most important do not delete or make copies of it.

In git bash do the following steps to run the script properly:

1) export SUPABASE_ACCESS_TOKEN="sbp_9844db773babd409c07fa323834368989a22a153"
copy this and paste it in git bash as it is.


2) Then after the first step run this command 
npx supabase --version.

3) Then for the script to start run this command:
sh supabase_edge_functions.sh

for MacOS:

- chmod +x supabase_edge_functions.sh
- ./supabase_edge_functions.sh -- Use this every time to call the script or run the script after setting the environment. 